/**
 * WhatsApp Client Module
 */

const fs = require("fs");
const path = require("path");
const { Client, LocalAuth } = require("whatsapp-web.js");
const { log } = require("../utils/logger");
const { TARGET_WHATSAPP_GROUP } = require("../config");
const { onReady } = require("./handlers/ready");

let whatsappGroupChat = null;
let whatsappClient    = null;

function initializeWhatsApp(callbacks) {
    log("[System] Initializing WhatsApp Client...");
    const dataDir = process.env.APP_DATA_DIR || "./data";
    const authPath = process.env.WHATSAPP_AUTH_PATH || path.join(dataDir, "wwebjs_auth");
    const legacyAuthPath = "./.wwebjs_auth";
    fs.mkdirSync(path.dirname(authPath), { recursive: true });
    if (!fs.existsSync(authPath) && fs.existsSync(legacyAuthPath)) {
        // Preserve existing WhatsApp login state when moving storage into a Docker-persistent directory.
        fs.cpSync(legacyAuthPath, authPath, { recursive: true });
        log("[WhatsApp] Migrated legacy authentication data to the persistent data directory.");
    }
    whatsappClient = new Client({
        authStrategy: new LocalAuth({ dataPath: authPath }),
        puppeteer: {
            headless: true,
            args: [
                "--no-sandbox", 
                "--disable-setuid-sandbox", 
                "--disable-dev-shm-usage", 
                "--disable-gpu",
                "--disable-site-isolation-trials", 
                "--disable-features=IsolateOrigins"
            ],
        }
    });

    whatsappClient.on("qr", (qr) => {
        const qrcode = require("qrcode-terminal");
        qrcode.generate(qr, { small: true });
    });

    whatsappClient.on("ready", async () => {
        log("[WhatsApp] ✅ Connected and ready!");
        whatsappGroupChat = null;
        try {
            const targetName = (TARGET_WHATSAPP_GROUP || "").trim();
            if (!targetName) {
                log("[WhatsApp] ❌ WHATSAPP_GROUPS is empty; sending is disabled until configuration is fixed.");
            } else {
                const chats = await whatsappClient.getChats();
                const matches = chats.filter(c => c.isGroup && String(c.name || "").trim() === targetName);
                if (matches.length === 1) {
                    whatsappGroupChat = matches[0];
                    log(`[WhatsApp] ✅ Target group located: ${whatsappGroupChat.name}`);
                } else if (matches.length === 0) {
                    log(`[WhatsApp] ❌ Exact target group not found: ${targetName}`);
                } else {
                    log(`[WhatsApp] ❌ Multiple groups have the exact target name: ${targetName}; refusing to guess.`);
                }
            }
        } catch (err) {
            log("[WhatsApp] ❌ Error fetching chats: " + (err.message || err));
        }

        // Start Telegram even if the WhatsApp target is misconfigured. Failed sends remain pending
        // and retry after the destination is fixed; ingestion should not depend on a group-name match.
        try {
            await onReady(callbacks);
        } catch (err) {
            log("[System] Could not start Telegram after WhatsApp readiness: " + (err.message || err));
        }
    });

    whatsappClient.on("auth_failure", message => {
        log("[WhatsApp] ❌ Authentication failure: " + (message || "unknown reason"));
    });
    whatsappClient.on("disconnected", reason => {
        whatsappGroupChat = null;
        log("[WhatsApp] ⚠️ Disconnected: " + (reason || "unknown reason"));
    });

    whatsappClient.initialize().catch(err => {
        log("[WhatsApp] ❌ Initialization failed: " + (err.message || err));
    });
}

/**
 * שליחת התרעה חדשה
 */
async function sendAlert(source, target, estimated_time) {
    if (!whatsappGroupChat) {
        log("[WhatsApp] Alert retained: target group is not available.");
        return null;
    }
    const alertMsg =
        `🚨 *התרעה - שיגורים בדרכם!* 🚨\n\n` +
        `📍 *מקור:* ${source          || "לא ידוע"}\n` +
        `🎯 *יעד:* ${target            || "לא ידוע"}\n` +
        `⏱️ *זמן משוער:* ${estimated_time || "לא ידוע"}\n\n` +
        `⏱️ *להצטרפות להתרעות לפני פיקוד העורף:* https://chat.whatsapp.com/GuyC5q1jjOc3cKTJj3gYn6?mode=gi_t`;

    try {
        await whatsappGroupChat.sendMessage(alertMsg);
        log("[WhatsApp] 📤 Alert sent!");
        return { source, target, estimated_time, publishedAt: Date.now() };
    } catch (err) {
        log("[WhatsApp] ❌ Failed to send: " + err);
        return null;
    }
}

/**
 * שליחת עדכון לאירוע קיים
 * 
 * @param {object} updatedFields - השדות המעודכנים { source, target, estimated_time }
 * @param {object} prevPublished - מה היה לפני
 * @param {string} updateType    - "target" | "time" | "target+time"
 */
async function sendUpdate(updatedFields, prevPublished, updateType) {
    if (!whatsappGroupChat) {
        log("[WhatsApp] Update retained: target group is not available.");
        return null;
    }
    const updateLabel = {
        "target":      "אזור יעד",
        "time":        "זמן הגעה",
        "target+time": "אזור יעד וזמן הגעה",
    }[updateType] || "פרטים";

    const alertMsg =
        `🔄 *התרעה - עדכון ${updateLabel}* 🔄\n\n` +
        `📍 *מקור:* ${updatedFields.source          || prevPublished.source || "לא ידוע"}\n` +
        `🎯 *יעד:* ${updatedFields.target            || prevPublished.target || "לא ידוע"}\n` +
        `⏱️ *זמן משוער:* ${updatedFields.estimated_time || prevPublished.estimated_time || "לא ידוע"}\n\n` +
        `⏱️ *להצטרפות להתרעות לפני פיקוד העורף:* https://chat.whatsapp.com/GuyC5q1jjOc3cKTJj3gYn6?mode=gi_t`;

    try {
        await whatsappGroupChat.sendMessage(alertMsg);
        log("[WhatsApp] 📤 Update sent!");
        return {
            source:         updatedFields.source          || prevPublished.source,
            target:         updatedFields.target          || prevPublished.target,
            estimated_time: updatedFields.estimated_time  || prevPublished.estimated_time,
            publishedAt:    Date.now(),
        };
    } catch (err) {
        log("[WhatsApp] ❌ Failed to send update: " + err);
        return null;
    }
}

async function shutdownWhatsApp() {
    if (whatsappClient) await whatsappClient.destroy();
}

module.exports = { initializeWhatsApp, sendAlert, sendUpdate, shutdownWhatsApp };